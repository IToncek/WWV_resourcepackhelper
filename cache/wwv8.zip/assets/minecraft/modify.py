import os
import json
import glob
import numpy as np 
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from PIL import Image
import PIL.ImageOps

image_formats = ["png", "jpg"]; # Let suppose we want to display png & jpg images (specify more if you want)

def show_images(image_file_name):
    image = Image.open(image_file_name)
    if image.mode == 'RGBA':
        r,g,b,a = image.split()
        rgb_image = Image.merge('RGB', (r,g,b))
        inverted_image = PIL.ImageOps.blur(rgb_image)
        r2,g2,b2 = inverted_image.split()
        final_transparent_image = Image.merge('RGBA', (r2,g2,b2,a))
        final_transparent_image.save(image_file_name)
    else:
        inverted_image = PIL.ImageOps.blur(image)
        inverted_image.save(image_file_name)

#def get_image_paths(current_dir):
#    files = os.listdir(current_dir);
#    paths = []; # To store relative paths of all png and jpg images
#
#    for file in files:
#        file = file.strip()
#        if os.path.isdir(file) and 'stone' in file:
#            for image_format in image_formats:
#               image_paths = glob.glob(os.path.join(".", file, "*." + image_format))
#                if image_paths:
#                    paths.extend(image_paths);
#
#    return paths

class BasicDeformer:
    def getmesh(self, im):
        x, y = im.size
        return [((0, 0, x, y), (0, 0, x, 0, x, y, y, 0))]

def get_image_paths(current_dir):
    rootdir = os.getcwd()

    for subdir, dirs, files in os.walk(rootdir):
        for file in files:
            #print os.path.join(subdir, file)
            filepath = subdir + os.sep + file

            if filepath.endswith(".png"):
                image = Image.open(filepath).convert('RGBA')
                deformer = BasicDeformer();
                if image.mode == 'RGBA':
                    r,g,b,a = image.split()
                    rgb_image = Image.merge('RGB', (r,g,b))

                    inverted_image = PIL.ImageOps.posterize(rgb_image, 2)

                    r2,g2,b2 = inverted_image.split()

                    final_transparent_image = Image.merge('RGBA', (r2,g2,b2,a))

                    final_transparent_image.save(filepath)

                else:
                    inverted_image = PIL.ImageOps.posterize(image, 2)
                    inverted_image.save(filepath)
            print("converted")

if __name__ == "__main__":
    image_paths = get_image_paths(".");